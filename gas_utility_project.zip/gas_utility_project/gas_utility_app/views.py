from django.shortcuts import render,redirect
from .forms import CustomerRegistrationForm,ServiceRequestForm
from .models import ServiceRequest
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect
# Create your views here.
def login(request):
    return(request,'registration/login.html')

def register_customer(request):
    if request.method=='POST':
        form = CustomerRegistrationForm(request.POST)

        if form.is_valid():
            form.save()
            return  HttpResponseRedirect('/home/submit')
    else:
        form =CustomerRegistrationForm()
    return render(request,'register_customer.html',{'form':form})


def submit_request(request):
    if request.method=='POST':
        form=ServiceRequestForm(request.POST,request.FILES)
        if form.is_valid():
            '''service_request=form.save(commit=False)
            service_request.customer=request.user
            service_request.save()'''
            form.save(commit=True)
            return redirect('track_request')
    else:
        form=ServiceRequestForm()
    return render(request,'submit_request.html',{'form':form })

def track_request(request):
    user=request.user
    service_requests=ServiceRequest.objects.filter(customer=user)
    return render(request,'track_request.html',{'service_requests':service_requests})


