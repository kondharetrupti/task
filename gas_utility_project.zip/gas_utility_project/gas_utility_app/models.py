from django.db import models

# Create your models here.
class Customer(models.Model):
    first_name=models.CharField(max_length=20)
    last_name=models.CharField(max_length=20)
    email=models.EmailField(unique=True)

class ServiceRequest(models.Model):
    customer=models.ForeignKey(Customer,on_delete=models.CASCADE)
    request_type=models.CharField(max_length=100)
    details=models.TextField()
    attachment=models.FileField(upload_to=None,null=True,blank=True)
    status=models.CharField(max_length=50,default='pending')
    submitted_at=models.DateTimeField(auto_now_add=True)
    resolved_at=models.DateTimeField(null=True,blank=True)