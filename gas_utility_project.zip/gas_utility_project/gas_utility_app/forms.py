from django import forms
from .models import Customer,ServiceRequest
class CustomerRegistrationForm(forms.ModelForm):
    class Meta:
        model=Customer
        fields=['first_name','last_name','email']

class ServiceRequestForm(forms.ModelForm):
    class Meta:
        model=ServiceRequest
        fields=['request_type','details','attachment']
