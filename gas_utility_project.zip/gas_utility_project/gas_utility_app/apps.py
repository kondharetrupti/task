from django.apps import AppConfig


class GasUtilityAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gas_utility_app'
